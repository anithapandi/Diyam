

var timeLineDataList = [
	{
		"year" : "Diyam",
		"title" : "Our achievements",
		"content": "About Diyam"
	},
	{
		"year" : "2018",
		"title" : "Our achievements",
		"content": "These are our achievements in 2018"
	},
	{
		"year" : "2017",
		"title" : "Our achievements",
		"content": "These are our achievements in 2017"
	},
	{
		"year" : "2016",
		"title" : "Our achievements",
		"content": "These are our achievements in 2016"
	}
];

